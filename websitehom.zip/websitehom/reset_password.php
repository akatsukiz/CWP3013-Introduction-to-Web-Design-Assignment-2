<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Reset Password</title>
    <link rel="stylesheet" href="./CSS/style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>
    <main id="reset_password" class="forgot_page login_page">
        <form id="validate_token" action="./Helpers/reset_password.php" method="POST">
            <a href="/">
                <img src="./images/logo.jpg" alt="Logo Gifted Students" loading="lazy">
            </a>
            <input type="hidden" name="email" value="<?= $_GET["email"] ?>">
            <div class="input">
                <label for="code">Code</label>
                <input type="text" name="code" id="code" required>
            </div>
            <div class="input">
                <label for="new_password">New password</label>
                <input type="password" name="new_password" id="new_password" required>
            </div>
            <div class="input">
                <label for="confirm_new_password">Confirm password</label>
                <input type="password" name="confirm_new_password" id="confirm_new_password" required>
            </div>
            <button>Reset</button>
        </form>
    </main>

</body>

</html>