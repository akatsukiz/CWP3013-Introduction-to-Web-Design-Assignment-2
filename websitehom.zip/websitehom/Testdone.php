<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Test Done</title>
    <style>
    	body {
            text-align: center;
        }
    </style>
</head>
<body>
    <?php
        // Connect to the database
        $hostName = "localhost";
        $userName = "root";
        $password = "";
        $databaseName = "giftedstudentdb";
        $conn = new mysqli($hostName, $userName, $password, $databaseName);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
            echo "<h1>"."You have successfully submitted your test<br>Returning to your dashboard"."<h1>";
            
        ?>
</body>
</html>
