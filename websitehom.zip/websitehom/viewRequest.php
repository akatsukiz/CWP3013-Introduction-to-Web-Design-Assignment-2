<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}
// Create Connection
require("./Modules/db_connect.php");

$no = "";
$status = "";
$teacher_id = 0;
$exam_code = "";
$stu_id = 0;
$section = "";
$suggested_mark = 0;
$reason = "";
$inserted_mark = 0;
$original_mark = 0;
$ori_overall_score = 0;
$overall_score = 0;
$overall_grade = "";
$student_ans = "";
$question = "";


if($_SERVER["REQUEST_METHOD"] == "GET"){
    
    if(!isset($_GET['no'])){
        header("Location: ../checkRequest.php");
        exit;
    }

    $no = $_GET['no'];

    // Fetch data from database
    $sql = "SELECT * FROM mark_change_request WHERE no = $no";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $status = $row['status'];
    $teacher_id = $row['teacher_id'];
    $exam_code = strval($row['exam_code']);
    $stu_id = $row['stu_id'];
    $section = $row['section'];
    $suggested_mark = $row['suggested_mark'];
    $reason = $row['reason'];
    $inserted_mark = $row['inserted_mark'];
    $original_mark = $row['original_mark'];

    // Define a mapping of question types to column names
    $question_to_column = array(
        "Short Answer 1" => "short_ans_1",
        "Short Answer 2" => "short_ans_2",
        "Essay" => "essay"
    );

    // Get the column name based on the question type 
    $column_name = $question_to_column[$section];

    // As cant use join for variable column name (e.g.: SELECT e.$column_name), hence, fetch separately
    $sql = "SELECT $column_name FROM exam_question WHERE exam_code = '$exam_code'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $question = $row[$column_name];

    $sql = "SELECT $column_name FROM student_answer WHERE stu_id = $stu_id AND exam_code = '$exam_code'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $student_ans = $row[$column_name];
}

else {
    // Post method: Update the mark of the student
    $section=$_POST['section'];
    $inserted_mark=$_POST['inserted_mark'];
    $exam_code=$_POST['exam_code'];
    $stu_id=$_POST['student_id'];
    $original_mark=$_POST['original_mark'];
    $no=$_POST['no'];
    $question_to_column = array(
        "Short Answer 1" => "short_ans_1",
        "Short Answer 2" => "short_ans_2",
        "Essay" => "essay"
    );
    $column_name = $question_to_column[$section];

    $sql = "SELECT overallscore FROM exam_result WHERE stu_id = $stu_id AND exam_code = '$exam_code'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $ori_overall_score=$row['overallscore'];
    

    // Get the column name based on the question type 
    $sql = "UPDATE exam_result SET $column_name = '$inserted_mark'
    WHERE exam_code = '$exam_code' AND stu_id = '$stu_id'";
    if($conn->query($sql) === TRUE) {
        $sql2 = "UPDATE mark_change_request SET inserted_mark = '$inserted_mark', status = 'Reviewed' WHERE no = '$no'";
        $conn->query($sql2);
        if ($inserted_mark != $original_mark) {
            $overall_score = ($ori_overall_score - $original_mark + $inserted_mark);
            $overall_grade = ($overall_score >= 80) ? 'A' : (($overall_score >= 70) ? 'B' : (($overall_score >= 60) ? 'C' : (($overall_score >= 50) ? 'D' : 'F')));
            $sql3 = "UPDATE exam_result SET overallscore = '$overall_score', grade = '$overall_grade' WHERE exam_code = '$exam_code'
            AND stu_id = '$stu_id'";
            $conn->query($sql3);
            }
            header("Location: ../checkRequest.php");
            exit; 
    }
    else{
        echo "<script>
        alert('Unable to update the mark, please contact the system admin to resolve the issue.');
        window.location.href='../checkRequest.php';
        </script>";
        exit; 
    }
     
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Mark Change Request</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/styles.css">
    <link rel="stylesheet" href="../CSS/style.css">
    <script>
        function validateForm() {
            var new_mark = document.forms["submitForm"]["inserted_mark"].value;
            if (new_mark == "" || new_mark.trim() === '') {
                document.getElementById("markMsg").innerHTML = "*The new mark should not be empty.";
                return false;
            }
            else if (isNaN(new_mark) || new_mark.includes('.')) {
                document.getElementById("markMsg").innerHTML = "*New mark should be an integer.";
                return false;
            }
            else if (new_mark < <?php echo $original_mark; ?> || new_mark > <?php echo $suggested_mark; ?>) {
                document.getElementById("markMsg").innerHTML = "*New mark should be between original mark and suggested mark.";
                return false;
            }
            else{
                return true;
            }
        }
    </script>
</head>
<body>
    <header>
        <a href="/">
            <img src="./images/logo.jpg" alt="Logo Gifted Student" loading="lazy">
        </a>
        <nav>
            <ul>
                <li>
                    <a href="/">
                        Homepage
                    </a>
                </li>
                <li>
                    <a href="../dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam Section
                    </a>
                </li>
                <li>
                    <a href="../admin_login.php">
                        Admin Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam table
                    </a>
                </li>
            </ul>
        </nav>
        <div class="login_buttons">
            <?php
            if (!isset($_SESSION["user_email"])) :
            ?>
                <a href="/login.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H18C18 18.6863 15.3137 16 12 16C8.68629 16 6 18.6863 6 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11Z"></path>
                    </svg>
                    Log In
                </a>
                <a href="/signup.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 15H6V20H18V4H6V9H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V15ZM10 11V8L15 12L10 16V13H2V11H10Z"></path>
                    </svg>
                    Sign Up
                </a>
            <?php
            else :
            ?>
                <a href="/profile.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"></path>
                    </svg>
                    My Profile
                </a>
            <?php
            endif;
            ?>
        </div>
    </header>
    <div class="container my-5">
        <h2>Mark Change Request</h2>
        <form name ="submitForm" method="post" onsubmit="return validateForm()">
        <div class = "container">
            <div class="row mb-3">
                <label class="col-sm-2 col-form-label">Request No:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="no" value="<?php echo $no; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Status:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="status" value="<?php echo $status; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Teacher ID:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="teacher_id" value="<?php echo $teacher_id; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Exam Code:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="exam_code" value="<?php echo $exam_code; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Student ID:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="student_id" value="<?php echo $stu_id; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Section:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="section" value="<?php echo $section; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Original Mark:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="original_mark" value="<?php echo $original_mark; ?>">
                </div>
                <label class="col-sm-2 col-form-label">Suggested Mark:</label>
                <div class="col-sm-10">
                    <input type="text" readonly class="form-control-plaintext" name="suggested_mark" value="<?php echo $suggested_mark; ?>">
                </div>
                </div>
                <div class="form-group">
                <label class="col-sm-2 col-form-label">Reason of Changes:</label>
                <textarea class="form-control" type="text" readonly class="form-control-plaintext name="reason" row="6"><?php echo $reason; ?></textarea>
                </div>
                <br>
                <div class="form-group">
                <label class="col-sm-2 col-form-label">Question:</label>
                <textarea class="form-control" type="text" readonly class="form-control-plaintext name="question" row="6"><?php echo $question; ?></textarea>
                </div>
                <br>
                <div class="form-group">
                <label class="col-sm-2 col-form-label">Student Answer:</label>
                <textarea class="form-control" type="text" readonly class="form-control-plaintext name="stu_ans" row="10"><?php echo $student_ans; if(isset($_POST['stu_ans'])){echo $_POST['stu_ans'];} ?></textarea>
                </div>
                <br>
                <?php 
                if($status == 'Pending') {
                    echo '<div class="input-group mb-3">
                          <label class="col-sm-2 col-form-label">New Mark:</label>
                          <input type="text" class="form-control" name="inserted_mark" placeholder="Enter New Marks"/>
                          <div class="input-group-append">
                          <button class="btn btn-primary" type="submit">Update Marks</button>
                          </div>
                          </div>
                          <div id="markMsg" style="color:Red"></div>';
                }
                else {
                    echo "<label class='col-sm-2 col-form-label'>Inserted Mark:</label>
                          <div class='col-sm-10'>
                             <input type='text' readonly class='form-control-plaintext' id='Inserted Mark' value='$inserted_mark'>
                            </div>";
                }
                 ?>
            </div>
        </div>
        </form>
        <a class="btn btn-outline-primary offset-sm-5 col-sm-2 d-grid" href="../checkRequest.php">Go Back</button>
    </div>
</body>
</html>