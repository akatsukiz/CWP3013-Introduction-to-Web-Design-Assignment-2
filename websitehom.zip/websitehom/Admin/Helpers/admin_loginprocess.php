<?php 
session_start(); 

$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "giftedstudentdb";
// Create Connection
$conn = new mysqli($hostName, $userName, $password, $databaseName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    echo "Connected successfully";
}


// retrieve data
$username = $_POST['username'];
$password = $_POST['password'];

// verify credentials
$stmt = $conn->prepare("SELECT * FROM admin WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    if($username == $row["username"] && $password == $row["password"]){
        $_SESSION["username"] = $row["username"];
        header("Location: /Admin/admin_page.php", true, 303);
        die;
    }

} else {
    header("Location: /admin_login.php?error=1", true, 303);
    die;
}

$stmt->close();
$conn->close();