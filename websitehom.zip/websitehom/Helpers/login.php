<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if(isset($_SESSION["user_email"])){
    header("Location: ../dashboard.php", true, 303);
    die;
}

require("../Modules/db_connect.php");

// retrieve data
$username = $_POST['username'];
$password = $_POST['password'];

// verify credentials
$stmt = $conn->prepare("SELECT * FROM user WHERE username = ? AND pass = ?");
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    if($username == $row["username"] && $password == $row["pass"]){
        $_SESSION["user_email"] = $row["email"];
        $_SESSION["user_id"] = $row["id"];
        header("Location: ../dashboard.php", true, 303);
        die;
    }

} else {
    header("Location: ../login.php?error=1", true, 303);
    die;
}

$stmt->close();
$conn->close();