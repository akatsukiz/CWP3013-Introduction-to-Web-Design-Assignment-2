<?php
session_start();

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}

require("../Modules/db_connect.php");

function cleanData($data)
{
    if (empty($data)) {
        header("Location: ../signup.php?error=10", true, 303);
        die;
    }

    return htmlspecialchars(stripslashes(trim($data)));
}

// Retrieve data
$email = cleanData($_POST['email']);
$confirm_email = cleanData($_POST['confirm_email']);
$username = cleanData($_POST['username']);
$password = cleanData($_POST['password']);
$confirm_password = cleanData($_POST['confirm_password']);


// Check if mails match
if ($email != $confirm_email) {
    header("Location: ../signup.php?error=1", true, 303);
    die;
}

// Check if passwords match
if ($password != $confirm_password) {
    header("Location: ../signup.php?error=2", true, 303);
    die;
}

// Check if there already is a username existant
$stmt = $conn->prepare("SELECT * FROM user WHERE LOWER(username) = LOWER(?)");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    header("Location: ../signup.php?error=3", true, 303);
    die;
}

// Check if there already is a email existant
$stmt = $conn->prepare("SELECT * FROM user WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    header("Location: ../signup.php?error=4", true, 303);
    die;
}

// Hash password
$hashed_password = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

// Retrieve accounts number to increment "id" column
$result = $conn->query("SELECT MAX(id) AS highest FROM user");
$row = $result->fetch_assoc();
$highest_id = $row['highest'];

// calcul new id
$new_id = $highest_id + 1;

// Insert value
$stmt = $conn->prepare("INSERT INTO user (id, email, username, pass, first_name, last_name, school, phone_no, address, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// with those default value
$first_name = "First Name";
$last_name = "Last Name";
$school = "School";
$phone_no = "123456789";
$address = "address";
$type = "student";

// and insert them inside the table
$stmt->bind_param("isssssssss", $new_id, $email, $username, $password, $first_name, $last_name, $school, $phone_no, $address, $type);

$stmt->execute();

$_SESSION["user_email"] = $email;
header("Location: ../profile.php", true, 303);
die;

$stmt->close();
$conn->close();
