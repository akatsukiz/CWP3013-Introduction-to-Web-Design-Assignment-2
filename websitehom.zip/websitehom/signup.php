<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if(isset($_SESSION["user_email"])){
    header("Location: ../index.php", true, 303);
    die;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Sign Up</title>
    <link rel="stylesheet" href="./CSS/style.css">
</head>

<body>
    <main class="login_page">
        <div class="background"></div>
        <form action="./Helpers/signup.php" method="POST">
            <a href="/">
                <img src="./images/logo.jpg" alt="Logo Gifted Students" loading="lazy">
            </a>
            <?php
            if (isset($_GET["error"])) :
                if ($_GET["error"] == 1) :
            ?>
                    <p class="error">Not matching emails</p>
                    <?php elseif($_GET["error"] == 2): ?>
                    <p class="error">Not matching passwords</p>
                    <?php elseif($_GET["error"] == 3): ?>
                    <p class="error">This username is already taken</p>
                    <?php elseif($_GET["error"] == 4): ?>
                    <p class="error">This email already exists</p>
                    <?php elseif($_GET["error"] == 10): ?>
                    <p class="error">Every fields are required</p>
            <?php
                endif;
            endif;
            ?>
            <div class="input">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
                <label for="confirm_email">Confirm email</label>
                <input type="email" name="confirm_email" id="confirm_email" required>
            </div>
            <div class="input">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required minlength="2" maxlength="96">
            </div>
            <div class="input">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
                <label for="confirm_password">Confirm password</label>
                <input type="password" name="confirm_password" id="confirm_password" required>
            </div>
            <button>Sign Up</button>
        </form>
    </main>
</body>

</html>