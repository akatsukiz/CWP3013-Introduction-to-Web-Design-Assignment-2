<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}

require("./Modules/db_connect.php");;
if(isset($_POST["password"])){
$id = $_SESSION["user_id"];
$pass = $_POST["password"];
$query = "DELETE FROM user WHERE id = ? and pass = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $id, $pass);
$result = $stmt->execute();
if($result == TRUE){
    echo "User successfully deleted
    <script>
    location.href = '../index.php';
    </script>";
}
else{
    echo "You have entered incorrect password, process not successful.";
    header("Location: ../dashboard.php");
}
}
else{
    echo "Something went wrong";
    header("Location:../dashboard.php");
}
?>