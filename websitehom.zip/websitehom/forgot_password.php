<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Forgot Password</title>
    <link rel="stylesheet" href="./CSS/style.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>
    <main id="reset_password" class="forgot_page login_page">
        <form id="send_token" action="./Helpers/forgot_password.php" method="POST">
            <a href="/">
                <img src="./images/logo.jpg" alt="Logo Gifted Students" loading="lazy">
            </a>
            <p>Enter your email address</p>
            <div class="input">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            <button>Send Code</button>
        </form>
    </main>

</body>

</html>