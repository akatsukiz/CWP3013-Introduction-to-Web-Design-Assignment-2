<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}

require("./Modules/db_connect.php");

// Retrieve user data
$stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
$stmt->bind_param("s", $_SESSION["user_email"]);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    session_destroy();
    header("Location: ../signup.php", true, 303);
    die;
}

$stmt->close();
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Dashboard</title>
    <link rel="stylesheet" href="./CSS/style.css">
</head>

<body>

    <header>
        <a href="/">
            <img src="./images/logo.jpg" alt="Logo Gifted Student" loading="lazy">
        </a>
        <nav>
            <ul>
                <li>
                    <a href="/">
                        Homepage
                    </a>
                </li>
                <li>
                    <a href="../dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam Section
                    </a>
                </li>
                <li>
                    <a href="../admin_login.php">
                        Admin Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam table
                    </a>
                </li>
            </ul>
        </nav>
        <div class="login_buttons">
            <?php
            if (!isset($_SESSION["user_email"])) :
            ?>
                <a href="/login.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H18C18 18.6863 15.3137 16 12 16C8.68629 16 6 18.6863 6 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11Z"></path>
                    </svg>
                    Log In
                </a>
                <a href="/signup.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 15H6V20H18V4H6V9H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V15ZM10 11V8L15 12L10 16V13H2V11H10Z"></path>
                    </svg>
                    Sign Up
                </a>
            <?php
            else :
            ?>
                <a href="/profile.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"></path>
                    </svg>
                    My Profile
                </a>
            <?php
            endif;
            ?>
        </div>
    </header>
    <main class="dashboard">
        <a href="./Helpers/logout.php">Log Out</a>
        <form action="./Helpers/update_user_data.php" method="POST">
            <img src="./images/user.webp" alt="User Image" loading="lazy">
            <?php
            if (isset($_GET["error"])) :
                if ($_GET["error"] == 10) :
            ?>
                    <p class="error">Empty values aren't allowed</p>
            <?php
                endif;
            endif;
            ?>
            <p><?= $row["username"] ?></p>
            <div class="input">
                <label for="school">School Name</label>
                <input type="text" name="school" id="school" value="<?= $row["school"] ?>" required>
            </div>
            <div class="input">
                <label for="firstname">First name</label>
                <input type="text" name="firstname" id="firstname" value="<?= $row["first_name"] ?>" required>
            </div>
            <div class="input">
                <label for="lastname">Last name</label>
                <input type="text" name="lastname" id="lastname" value="<?= $row["last_name"] ?>" required>
            </div>
            <div class="input">
                <label for="phone_number">Phone number</label>
                <input type="text" name="phone_number" id="phone_number" value="<?= $row["phone_no"] ?>" required>
            </div>
            <div class="input">
                <label for="address">Address</label>
                <input type="text" name="address" id="address" value="<?= $row["address"] ?>" required>
            </div>
            <button>Update my profile</button>
        </form>
    </main>
</body>

</html>