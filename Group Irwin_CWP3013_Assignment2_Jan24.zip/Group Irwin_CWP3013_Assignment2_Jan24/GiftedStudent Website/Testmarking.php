<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Test Marking</title>
    <style>
        body {
            position: relative;
            font-family: Arial, sans-serif;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: right;
            margin-top: 60px;
        }

        .question {
            margin: 5px 0;
        }

        .form-button {
            width: 200px;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button-container {
            justify-content: center;
        }
    </style>
</head>
<body>
    <?php
        // Connect to the database
        $hostName = "localhost";
        $userName = "root";
        $password = "";
        $databaseName = "giftedstudentdb";
        $conn = new mysqli($hostName, $userName, $password, $databaseName);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // First query to get exam details
        $query1 = "SELECT * FROM exam_question";
        $result1 = mysqli_query($conn, $query1);

        // Second query to get user details
        $query2 = "SELECT id, username FROM user";
        $result2 = mysqli_query($conn, $query2);


        if ($result1->num_rows > 0) {
            $row = $result1->fetch_assoc();
            $mcq_1 = $row["mcq_1"];
            $mcq_2 = $row["mcq_2"];
            $mcq_3 = $row["mcq_3"];
            $mcq_4 = $row["mcq_4"];
            $mcq_5 = $row["mcq_5"];
            $mcq_6 = $row["mcq_6"];
            $mcq_7 = $row["mcq_7"];
            $mcq_8 = $row["mcq_8"];
            $mcq_9 = $row["mcq_9"];
            $mcq_10 = $row["mcq_10"];
            $short_ans_1 = $row["short_ans_1"];
            $short_ans_2 = $row["short_ans_2"];
            $essay = $row["essay"];
        }

        // Default values for username and user_id
        $username = "Unknown";
        $user_id = "Unknown";

        if ($result2->num_rows > 0) {
            // Fetching username and user_id based on some condition, for example, first user in the result
            $row2 = $result2->fetch_assoc();
            $username = $row2["username"];
            $user_id = $row2["id"];
        }
    ?>
    <h3 align="center">Taking test as: <?php echo htmlspecialchars($username); ?> (ID: <?php echo htmlspecialchars($user_id); ?>)</br>
        Time Limit: 60 Minutes </h3>
    <div class="form-container">
        <form action="" method="POST">
            <div class="question">Question 1: <?php echo htmlspecialchars($mcq_1); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">sheeps</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">sheep</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">sheepies</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">sheepes</label><br>
            <br>
            <div class="question">Question 2: <?php echo htmlspecialchars($mcq_2); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">mangos</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">mangose</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">mangoes</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">mangies</label><br>
            <br>
            <div class="question">Question 3: <?php echo htmlspecialchars($mcq_3); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">manes</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">mans</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">men</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">manies</label><br>
            <br>
            <div class="question">Question 4: <?php echo htmlspecialchars($mcq_4); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">Sister</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">Uncle</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">Mother</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">Brother</label><br>
            <br>
            <div class="question">Question 5: <?php echo htmlspecialchars($mcq_5); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">7206</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">7333</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">7801</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">7060</label><br>
            <br>
            <div class="question">Question 6: <?php echo htmlspecialchars($mcq_6); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">6 + 21 = 27</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">15 + 6 = 21</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">27 - 15 = 12</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">15 - 6 = 9</label><br>
            <br>
            <div class="question">Question 7: <?php echo htmlspecialchars($mcq_7); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">70 + 4 = 74 miles</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">70 - 4 = 66 miles</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">70 + 70 + 70 = 210 miles</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">70 + 70 + 70 + 70 = 280 miles</label><br>
            <br>
            <div class="question">Question 8: <?php echo htmlspecialchars($mcq_8); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">triangle</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">pentagon</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">rectangle</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">hexagon</label><br>
            <br>
            <div class="question">Question 9: <?php echo htmlspecialchars($mcq_9); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">16 hundreds and 7 tens</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">1 hundred and 67 tens</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">1 thousand and 6 hundreds</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">16 thousands and 7 tens</label><br>
            <br>
            <div class="question">Question 10: <?php echo htmlspecialchars($mcq_10); ?></div>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option1">hexagon</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option2">octagon</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option3">pentagon</label><br>
            <input type="radio" id="option1" name="radio_group_name" value="Option 1"><label for="option4">rectangle</label><br>
            <br>
            <div class="question">Question 11: <?php echo htmlspecialchars($short_ans_1); ?></div>
            <textarea name="other" rows="5" cols="100"></textarea></p>
            <br>
            <div class="question">Question 12: <?php echo htmlspecialchars($short_ans_2); ?></div>
            <textarea name="other" rows="5" cols="100"></textarea></p>
            <br>
            <div class="question">Question 13: <?php echo htmlspecialchars($essay); ?></div>
            <textarea name="other" rows="9" cols="100"></textarea></p>
            <br>
        </form>
    </div>
    <div class="button-container" align="center">
        <form action="Testdone.php" method="POST">
            <p>Total Score points : <input type="text" name="score"><br></p>
        <button type="submit" class="form-button">Confirm Submission</button>
        </form>
    </div>
</body>
</html>