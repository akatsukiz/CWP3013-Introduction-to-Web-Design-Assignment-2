<?php
// Credentials
$server = "localhost";
$user = "root";
$password = "";
$db = "giftedstudentdb";

// DB Connection
$conn = new mysqli($server, $user, $password, $db);

// Test connection
if ($conn->connect_error) {
    die("Connection error: " . $conn->connect_error);
}
