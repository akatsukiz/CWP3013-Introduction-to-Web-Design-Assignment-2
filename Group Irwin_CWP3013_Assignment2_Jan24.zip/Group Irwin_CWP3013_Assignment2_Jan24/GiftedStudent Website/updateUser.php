<?php
require("./Modules/db_connect.php");
session_start();
if (isset($_SESSION['user_id']) && !(isset($_POST['update']))){
$id = $_SESSION['user_id'];
    $query = "SELECT * FROM user WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_array();
    $name = $user['username'];
    $school = $user['school'];
    $address = $user['address'];
    $phone = $user['phone_no'];
    $type = $user['type'];
    $email = $user['email'];
echo "<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
<title>User Dashboard|Update your details</title>
    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css'>
    <!-- jQuery -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <!-- Bootstrap JS (include Popper.js for Bootstrap tooltips & popovers) -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js'></script>
    <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>
    </head>

<body style='display: flex; align-items: center; justify-content: center; height: 100vh;'>
<form action='updateUser.php' method='post' style='background-color: #f8f9fa; padding: 20px; border-radius: 5px;'>
    <div class='form-group'>
        <label for='username' class='form-label'>Username</label>
        <input type='text' class='form-control' name='username' id='username' value='$name'/>
    </div>
    <div class='form-group'>
        <label for='school' class='form-label'>School</label>
        <input type='text' class='form-control' name='school' id='school' value='$school'/>
    </div>
    <div class='form-group'>
        <label for='address' class='form-label'>Address</label>
        <input type='text' class='form-control' name='address' id='address' value='$address'/>
    </div>
    <div class='form-group'>
        <label for='phone_no' class='form-label'>Phone Number</label>
        <input type='tel' class='form-control' name='phone_no' id='phone_no' value='$phone'/>
    </div>
    <div class='form-group'>
        <label for='email' class='form-label'>Email</label>
        <input type='email' class='form-control' name='email' id='email' value='$email'/>
    </div>
    <div class='form-group'>
        <input type='submit' class='btn btn-primary' name='update' value='Update'/>
    </div>
    </form>
</body>
    ";
}

elseif(isset($_POST['update'])){
    $id = $_SESSION['id'];
    $username = $_POST['username'];
    $school = $_POST['school'];
    $address = $_POST['address'];
    $phone_no = $_POST['phone_no'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];

    $query = "UPDATE user SET username=?, email=?, school=?, address=?,phone_no=?, dob=? WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt ->bind_param('ssssssi', $username, $email, $school,$address,$phone_no, $dob, $id);
    $stmt->execute();
    echo '<script type="text/javascript">
    alert("Your information is updated");
    </script>';
    header("Location:../dashboard.php");
}
?>