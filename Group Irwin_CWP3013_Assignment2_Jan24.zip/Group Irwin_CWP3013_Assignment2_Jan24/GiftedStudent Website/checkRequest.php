<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Check Mark Change Request</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/style.css">
</head>
<body>
    <header>
        <a href="/">
            <img src="./images/logo.jpg" alt="Logo Gifted Student" loading="lazy">
        </a>
        <nav>
            <ul>
                <li>
                    <a href="/">
                        Homepage
                    </a>
                </li>
                <li>
                    <a href="../dashboard.php">
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam Section
                    </a>
                </li>
                <li>
                    <a href="../admin_login.php">
                        Admin Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam table
                    </a>
                </li>
            </ul>
        </nav>
        <div class="login_buttons">
            <?php
            if (!isset($_SESSION["user_email"])) :
            ?>
                <a href="/login.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H18C18 18.6863 15.3137 16 12 16C8.68629 16 6 18.6863 6 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11Z"></path>
                    </svg>
                    Log In
                </a>
                <a href="/signup.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 15H6V20H18V4H6V9H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V15ZM10 11V8L15 12L10 16V13H2V11H10Z"></path>
                    </svg>
                    Sign Up
                </a>
            <?php
            else :
            ?>
                <a href="/profile.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"></path>
                    </svg>
                    My Profile
                </a>
            <?php
            endif;
            ?>
        </div>
    </header>
    <div>
        <div class="container my-5">
            <h2>List of Mark Change Request</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Number</th>
                        <th>Teacher ID</th>
                        <th>Exam Code</th>
                        <th>Student ID</th>
                        <th>Section</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Connect to database
                    require("./Modules/db_connect.php");
                    // Fetch data from database
                    $sql = "SELECT no, teacher_id, exam_code, stu_id, section, status FROM mark_change_request";
                    $result = $conn->query($sql);
                    if ($result->num_rows>0){
                        while($row = $result->fetch_assoc()){
                            if($row['status'] == 'Pending')
                                    {
                                        $buttonName = "Respond";
                                    }
                                    else
                                    {
                                        $buttonName = "View";
                                    }
                            echo "
                            <tr>
                                <td>$row[no]</td>
                                <td>$row[teacher_id]</td>
                                <td>$row[exam_code]</td>
                                <td>$row[stu_id]</td>
                                <td>$row[section]</td>
                                <td>$row[status]</td>
                                <td>
                                    <a class='btn btn-primary' href='../viewRequest.php?no=$row[no]'>$buttonName</a>
                                 </td>
                            </tr>
                            ";
                        }
                    }
                    else
                    {
                        echo "No mark change request at the moment.";
                    }
                    ?>
            </table>
                
    </div>
</body>
</html>