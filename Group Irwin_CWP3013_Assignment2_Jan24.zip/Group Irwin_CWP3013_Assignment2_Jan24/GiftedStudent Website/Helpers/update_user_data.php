<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}

require("../Modules/db_connect.php");

function cleanData($data)
{
    if (empty($data)) {
        header("Location: ../signup.php?error=10", true, 303);
        die;
    }

    return htmlspecialchars(stripslashes(trim($data)));
}

// Retrieve data
$school = $_POST['school'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone_number = $_POST['phone_number'];
$address = $_POST['address'];

// Update table
$stmt = $conn->prepare("UPDATE user SET school = ?, first_name = ?, last_name = ?, phone_no = ?, address = ? WHERE email = ?");
$stmt->bind_param("ssssss", $school, $firstname, $lastname, $phone_number, $address, $_SESSION["user_email"]);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: ../profile.php", true, 303);
    die;
} else {
    echo "Error while updating data";
}

$stmt->close();
$conn->close();