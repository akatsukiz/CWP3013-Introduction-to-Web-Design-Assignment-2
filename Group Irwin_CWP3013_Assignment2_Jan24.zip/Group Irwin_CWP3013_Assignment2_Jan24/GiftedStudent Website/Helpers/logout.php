<?php
session_start();
session_destroy();
header("Location: ../login.php", true, 303);
die;
