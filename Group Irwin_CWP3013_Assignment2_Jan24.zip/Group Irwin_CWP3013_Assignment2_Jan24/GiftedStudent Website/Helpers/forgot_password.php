<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require("../vendor/autoload.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}

$token = uniqid(mt_rand(), false);
$token = substr(preg_replace('/[^0-9]/', '', $token), 0, 10);

$file = fopen("../tokens/" . $_POST["email"] . ".txt", "w");
if ($file) {
    fwrite($file, $token);
    fclose($file);
} else {
    echo ("Error while creating the token");
}

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'irwinwongkahhoe@gmail.com';
    $mail->Password   = 'vykl pskv rmmu eyay';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465; // (587 for TLS, 465 for SSL)

    $mail->From = 'sender_mail@domainname.com';
    $mail->FromName = 'Gifted Students';
    $mail->addAddress($_POST["email"], 'Gifted Students');
    $mail->addReplyTo('sender_mail@domainname.com', 'Support');

    $mail->WordWrap = 50;                                 // Set word wrap to 50 characters
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = 'Reset your password';
    $mail->Body    = 'You requested to reset the password. Here is the new code to put on the website: ' . $token;
    $mail->AltBody = 'You requested to reset the password. Here is the new code to put on the website: ' . $token;

    if (!$mail->send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail->ErrorInfo;
    } else {
        header("Location: ../reset_password.php?email=" . $_POST["email"], true, 303);
        die;
    }
} catch (Exception $e) {
    echo "Error while sending the mail : {$mail->ErrorInfo}";
}
