<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}

require("../Modules/db_connect.php");

function cleanData($data)
{
    if (empty($data)) {
        header("Location: ../reset_password.php?email=" . $_POST["email"] . "&error=10", true, 303);
        die;        
    }

    return htmlspecialchars(stripslashes(trim($data)));
}

// Get the values ​​submitted by the form
$code = cleanData($_POST['code']);
$email = cleanData($_POST["email"]);
$password = cleanData($_POST['new_password']);
$confirm_password = cleanData($_POST['confirm_new_password']);

// Check if passwords match
if ($password != $confirm_password) {
    header("Location: ../reset_password.php?email=" . $_POST["email"] . "&error=2", true, 303);
    die;
}


$stmt = $conn->prepare("SELECT * FROM user WHERE LOWER(email) = LOWER(?)");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $stmt->close();

    $token = file_get_contents("../tokens/" . $email . ".txt");
    if ($token !== false) {

        if ($token === $code) {

            // SQL query to update the password in the user table
            $stmt = $conn->prepare("UPDATE user SET pass = ? WHERE email = ?");
            $stmt->bind_param("ss", $password, $email);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                unlink("../tokens/" . $email . ".txt");

                header("Location: ../login.php?sucess=1", true, 303);
                die;
            } else {
                echo "Could not modify the password.";
            }

            // Close connection


        } else {
            header("Location: ../reset_password.php?email=" . $_POST["email"] . "&error=1", true, 303);
            die;
        }
    } else {
        echo "Token doesn't exist";
    }
} else {
    echo ("This mail is not registered");
}
