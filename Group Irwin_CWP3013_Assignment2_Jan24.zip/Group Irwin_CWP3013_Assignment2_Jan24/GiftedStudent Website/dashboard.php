<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["user_email"])) {
    header("Location: ../login.php", true, 303);
    die;
}
require("./Modules/db_connect.php");

if(isset($_SESSION['user_id'])){
    $id = $_SESSION['user_id'];
    $query = "SELECT * FROM user WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_array();
    $name = $user['username'];
    $school = $user['school'];
    $address = $user['address'];
    $phone = $user['phone_no'];
    $type = $user['type'];
    $email = $user['email'];
    
echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css'>
    <link rel='stylesheet' href='../CSS/style.css'>
    <!-- jQuery --> 
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js'></script>
    <!-- Bootstrap JS (include Popper.js for Bootstrap tooltips & popovers) -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js'></script>
    <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>
</head>
<body>
<header>
        <a href='/'>
            <img src='./images/logo.jpg' alt='Logo Gifted Student' loading='lazy'>
        </a>
        <nav>
            <ul>
                <li>
                    <a href='/'>
                        Homepage
                    </a>
                </li>
                <li>
                    <a href='../dashboard.php'>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href='#'>
                        Exam Section
                    </a>
                </li>
                <li>
                    <a href='../Admin/admin_login.php'>
                        Admin Dashboard
                    </a>
                </li>
                <li>
                    <a href='#'>
                        Exam table
                    </a>
                </li>
            </ul>
        </nav>
        <div class='login_buttons'>";
            if (!isset($_SESSION['user_email'])) {
                echo "<a href='/login.php'>
                    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24' fill='currentColor'>
                        <path d='M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H18C18 18.6863 15.3137 16 12 16C8.68629 16 6 18.6863 6 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11Z'></path>
                    </svg>
                    Log In
                </a>
                <a href='/signup.php'>
                    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24' fill='currentColor'>
                        <path d='M4 15H6V20H18V4H6V9H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V15ZM10 11V8L15 12L10 16V13H2V11H10Z'></path>
                    </svg>
                    Sign Up
                </a>";}
            else {
                echo "
                <a href='/profile.php'>
                    <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' width='24' height='24' fill='currentColor'>
                        <path d='M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z'></path>
                    </svg>
                    My Profile
                </a>";
            }
            echo"
        </div>
    </header>
<div class='container'>
    <div class='row'>
        <div class='col-md-12'>
            <!-- User profile form -->
                <div>
                <h2>User Dashboard</h2>
                <button style='float:right;' class='btn btn-info' onclick="."location.href='./Helpers/logout.php'".">Logout</button>
                </div>
                <div class='form-group'>
                    <label for='username'>Username</label>
                    <input type='text' class='form-control' id='username' name='username' value='".$name."' readonly required>
                </div>
                <div class='form-group'>
                    <h2>Type</h2>
                    <h3>".$type."</h3>
                </div>
                <div class='form-group'>
                    <label for='schoolName'>School Name</label>
                    <input type='text' class='form-control' id='schoolName' name='schoolName' value='".$school."' readonly required>
                </div>
                <div class='form-group'>
                    <label for='email'>Email</label>
                    <input type='email' class='form-control' id='email' name='email' value='".$email."' readonly required>
                </div>
                <div class='form-group'>
                    <label for='phone'>Phone Number</label>
                    <input type='tel' class='form-control' id='phone' name='phone' value='".$phone."' readonly>
                </div>
                <div class='form-group'>
                    <label for='address'>Address</label>
                    <input type='text' class='form-control' id='address' name='address' value='".$address."' readonly>
                </div>";
                if ($type == 'student'){
                    echo "<button class='btn btn-primary' onclick="."location.href='../TestPage.php'".">Take test</button>";
                }elseif($type=='teacher'){
                    echo "<button class='btn btn-primary' onclick="."location.href='../Testmarking.php'".">Mark test</button>";
                    echo "<button class='btn btn-primary' onclick="."location.href='#'".">Request mark changes</button>";
                }elseif($type=='officer'){
                    echo "<button class='btn btn-primary' onclick="."location.href='../checkRequest.php'".">See Requests</button>";
                }
                echo "<button class='btn btn-info' onclick="."location.href='../updateUser.php"."';>Update Your user details</button>
                <button class='btn btn-danger' onclick=\"confirmAndSend();\">Delete your profile</button>
                <script>
                function confirmAndSend() {
                    var password = prompt('Please enter your password to confirm');
                    if (password) {
                        var form = document.createElement('form');
                        document.body.appendChild(form);
                        form.method = 'post';
                        form.action = 'delete.php';
            
                        var passwordInput = document.createElement('input');
                        passwordInput.type = 'hidden';
                        passwordInput.name = 'password';
                        passwordInput.value = password;
                        form.appendChild(passwordInput);
            
                        form.submit();
                    }
                }
                </script>
            </div>
        </div>
    </div>
</div>";
}
else{
    echo '<div class="alert alert-danger" role="alert">
    You must be logged in to view this page
    </div>';
    header('index.php');
}
echo"

</body>
</html>";
?>