<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Student</title>
    <link rel="stylesheet" href="./CSS/style.css">
</head>

<body>
    <header>
        <a href="/">
            <img src="./images/logo.jpg" alt="Logo Gifted Student" loading="lazy">
        </a>
        <nav>
            <ul>
                <li>
                    <a href="/">
                        Homepage
                    </a>
                </li>
                <li>
                    <a href="#">
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam Section
                    </a>
                </li>
                <li>
                    <a href="../Admin/admin_login.php">
                        Admin Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">
                        Exam table
                    </a>
                </li>
            </ul>
        </nav>
        <div class="login_buttons">
            <?php
            if (!isset($_SESSION["user_email"])) :
            ?>
                <a href="/login.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 22C4 17.5817 7.58172 14 12 14C16.4183 14 20 17.5817 20 22H18C18 18.6863 15.3137 16 12 16C8.68629 16 6 18.6863 6 22H4ZM12 13C8.685 13 6 10.315 6 7C6 3.685 8.685 1 12 1C15.315 1 18 3.685 18 7C18 10.315 15.315 13 12 13ZM12 11C14.21 11 16 9.21 16 7C16 4.79 14.21 3 12 3C9.79 3 8 4.79 8 7C8 9.21 9.79 11 12 11Z"></path>
                    </svg>
                    Log In
                </a>
                <a href="/signup.php">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                        <path d="M4 15H6V20H18V4H6V9H4V3C4 2.44772 4.44772 2 5 2H19C19.5523 2 20 2.44772 20 3V21C20 21.5523 19.5523 22 19 22H5C4.44772 22 4 21.5523 4 21V15ZM10 11V8L15 12L10 16V13H2V11H10Z"></path>
                    </svg>
                    Sign Up
                </a>
            <?php
            else :
            ?>
                <a href="/profile.php">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M20 22H18V20C18 18.3431 16.6569 17 15 17H9C7.34315 17 6 18.3431 6 20V22H4V20C4 17.2386 6.23858 15 9 15H15C17.7614 15 20 17.2386 20 20V22ZM12 13C8.68629 13 6 10.3137 6 7C6 3.68629 8.68629 1 12 1C15.3137 1 18 3.68629 18 7C18 10.3137 15.3137 13 12 13ZM12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z"></path></svg>
                    My Profile
                </a>
            <?php
            endif;
            ?>
        </div>
    </header>
    <main class="homepage">
        <section class="hero_banner">
            <div class="background"></div>
            <div class="text_content">
                <h1>This is Gifted Education</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit dolores debitis maxime recusandae autem inventore eos aperiam beatae iusto dolore minima ab vel sit tempore labore blanditiis, optio quibusdam. Tempore neque sit corporis placeat. Voluptate voluptatibus sapiente in ratione voluptas!</p>
                <a href="#" class="button">Get Started</a>
            </div>
        </section>
        <section class="video_section">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/LlCwHnp3kL4?si=SKxOshtizntNTp90" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            <div class="text_content">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus, similique et magnam culpa corporis impedit ab earum recusandae, error unde dolore accusamus, maiores natus eum repellendus repellat aliquid non at ducimus adipisci! Eum sapiente ab sunt molestiae voluptas rem iure quaerat debitis impedit est tempora, recusandae nemo sint? Molestiae, porro!</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque est vel iure aliquam, quaerat assumenda.</p>
            </div>
        </section>
        <section class="activity_list">
            <img src="./images/main section1.jpg" alt="Activity Picture" loading="lazy">
            <img src="./images/mainsection2.jpg" alt="Activity Picture" loading="lazy">
            <img src="./images/mainsection3.jpg" alt="Activity Picture" loading="lazy">
            <img src="./images/mainsection4.jpg" alt="Activity Picture" loading="lazy">
            <img src="./images/mainsection5.jpg" alt="Activity Picture" loading="lazy">
            <img src="./images/mainsection6.jpg" alt="Activity Picture" loading="lazy">
        </section>
        <section class="slide">
            <button class="arrow" onclick="leftSlide();">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m11.25 9-3 3m0 0 3 3m-3-3h7.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>

            </button>
            <div class="slide_content">
                <div class="text_content">
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Impedit quod inventore in placeat repellendus corrupti laborum reiciendis sequi. Qui velit asperiores ab. Eaque, placeat aperiam, maiores recusandae natus autem ipsum laudantium ducimus impedit ad architecto maxime ex! Ea dolorum assumenda quia, maxime quam rerum atque, libero a harum, numquam fugit!</p>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quidem doloribus aspernatur error molestias eveniet officiis iusto commodi eos, eaque repudiandae nisi vero vel aut quaerat, doloremque voluptatum, distinctio obcaecati voluptatem excepturi voluptates in reiciendis explicabo.</p>
                </div>
                <img src="./images/slide1.jpg" alt="Slide Image" loading="lazy">
            </div>
            <button class="arrow" onclick="rightSlide();">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
                    <path stroke-linecap="round" stroke-linejoin="round" d="m12.75 15 3-3m0 0-3-3m3 3h-7.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                </svg>

            </button>
        </section>
    </main>
    <footer>
        <p>Footer\\ 0205573 John Paul Yeap|0205226 Irwin Wong Kah Hoe|0207333 Ong Yi Wen|0207146 Tan Sin Yee|0207368 Chan Seow Fen</p>
    </footer>
    <script>
        const alumniData = [
            ["<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Impedit quod inventore in placeat repellendus corrupti laborum reiciendis sequi. Qui velit asperiores ab. Eaque, placeat aperiam, maiores recusandae natus autem ipsum laudantium ducimus impedit ad architecto maxime ex! Ea dolorum assumenda quia, maxime quam rerum atque, libero a harum, numquam fugit!</p><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quidem doloribus aspernatur error molestias eveniet officiis iusto commodi eos, eaque repudiandae nisi vero vel aut quaerat, doloremque voluptatum, distinctio obcaecati voluptatem excepturi voluptates in reiciendis explicabo.</p>", './images/slide1.jpg'],
            ["<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Impedit quod inventore in placeat repellendus corrupti laborum reiciendis sequi. Qui velit asperiores ab. Eaque, placeat aperiam, maiores recusandae natus autem ipsum laudantium ducimus impedit ad architecto maxime ex! Ea dolorum assumenda quia, maxime quam rerum atque, libero a harum, numquam fugit!</p><p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quidem doloribus aspernatur error molestias eveniet officiis iusto commodi eos, eaque repudiandae nisi vero vel aut quaerat, doloremque voluptatum, distinctio obcaecati voluptatem excepturi voluptates in reiciendis explicabo.</p>", './images/slide2.jpg']
        ];

        let index = 0;

        function leftSlide() {
            index == 0 ? index = alumniData.length - 1 : index--;
            slide(index)
        }

        function rightSlide() {
            index == alumniData.length - 1 ? index = 0 : index++;
            slide(index)
        }

        function slide(index) {
            document.getElementsByClassName("slide_content")[0].style.opacity = "0";
            setTimeout(() => {
                document.getElementsByClassName("slide_content")[0].innerHTML = `
                <div class="text_content">
                    ${alumniData[index][0]}
                </div>
                <img src="${alumniData[index][1]}" alt="Slide Image" loading="lazy">
                `;
            }, 300);
            setTimeout(() => {
                document.getElementsByClassName("slide_content")[0].style.opacity = "1";
            }, 500);
        }
    </script>
</body>

</html>