<?php

$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "giftedstudentdb";
// Create Connection
$conn = new mysqli($hostName, $userName, $password, $databaseName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    echo "Connected successfully";
}

$id = "";
$username = "";
$school = "";
$email ="";
$phone_no ="";
$address ="";
$type ="";

$errorMessage = "";
$successMessage ="";

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $id = $_POST["id"];
    $username = $_POST["username"];
    $school = $_POST["school"];
    $email = $_POST["email"];
    $phone_no = $_POST["phone_no"];
    $address = $_POST["address"];
    $type = $_POST["type"];

    if (empty($id) || empty($username) || empty($school) || empty($email) || empty($phone_no) || empty($address) || empty($type)) {
        $errorMessage = "All the fields are required";
    } else {
        // Prepared statement to insert data into the database
        $sql = "INSERT INTO user (id, username, school, email, phone_no, address, type) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            $errorMessage = "Error: " . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, "isssiss", $id, $username, $school, $email, $phone_no, $address, $type);

            if (mysqli_stmt_execute($stmt)) {
                $successMessage = "Client added correctly!";
            } else {
                $errorMessage = "Error: " . mysqli_error($conn);
            }

            mysqli_stmt_close($stmt);

            // Resetting the variables after successful insertion
            $id = "";
            $username = "";
            $school = "";
            $email ="";
            $phone_no ="";
            $address ="";
            $type ="";
        }
    }
}

mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Create New User</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
	<div class="container my-5">
		<h2>New Student</h2>

		<?php
			if (!empty($errorMessage)) {
				echo "
				<div class='alert alert-warning alert-dismissible fade show' role='alert'>
					<strong>$errorMessage</strong>
					<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
				</div>
					";
			}

		?>
		<form method="POST">
			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Id</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="id" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Name</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="username" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">School Name</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="school" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Email</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="email" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Phone Number</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="phone_no" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Address</label>
				<div class="col-sm-6">
					<input type="text" class="form-control" name="address" value="">
				</div>
			</div>

			<div class="row mb-3">
				<label class="col-sm-3 col-from-label">Type</label>
				<div class="col-sm-6">
					<select name="type" id="type">
						<option>Please Select One</option>
						<option value="student">Student</option>
						<option value="teacher">Teacher</option>
						<option value="officer">Officer</option>
					</select>
				</div>
			</div>

			<?php
				if (!empty($successMessage)) {
					echo "
					<div class='row mb-3'>
						<div class='offset-sm-3 col-sm-6'>
							<div class='alert alert-warning alert-dismissible fade show' role='alert'>
								<strong>$successMessage</strong>
								<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
							</div>
						</div>
					</div>
					";
				}

			?>

			<div class="row mb-3">
				<div class="col-sm-3 col-sm-3 d-grid">
					<button type="Submit" class="btn btn-primary">Submit</button>
				</div>
				<div class="col-sm-3 d-grid">
					<a class="btn btn-primary" href="/Admin/UserDisplay.php" role="button">Cancel</a>
				</div>
			</div>
		</form>
	</div>

</body>
</html>