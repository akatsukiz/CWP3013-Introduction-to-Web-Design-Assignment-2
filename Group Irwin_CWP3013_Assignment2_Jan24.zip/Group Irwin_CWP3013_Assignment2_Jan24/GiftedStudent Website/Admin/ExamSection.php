<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Exam Section</title>
    <style>
        body {
            position: relative;
        }

        .exit-button {
            position: absolute;
            top: 0;
            left: 0;
            margin: 20px;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .button-container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin-top: 60px;
            margin-bottom: 20px;
        }

        .search-box {
            display: flex;
            flex-direction: row;
            margin-right: 10px;
            margin-bottom: 10px;
        }

        .search-input {
            width: 70%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .search-button {
            width: 25%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-left: 1px solid #ccc;
            border-radius: 5px;
            margin-left: 10px;
            cursor: pointer;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .test-button {
            width: 100%;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
    <main class="login_page">
    <div>
        <button class="exit-button" onclick="history.go(-1);">Exit Page</button>
        <div class="button-container">
            <form id="searchExamCodeForm" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="search-box">
                    <input type="text" name="exam_code" id="examCodeInput" placeholder="Exam Code" class="search-input">
                    <input type="submit" value="Search" class="search-button">
                </div>
            </form>
            <form id="searchExamNameForm" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="search-box">
                    <input type="text" name="exam_name" id="examNameInput" placeholder="Exam Name" class="search-input">
                    <input type="submit" value="Search" class="search-button">
                </div>
            </form>
        </div>

        <table class="table">
            <thead>
                <tr align="center">
                    <th colspan="6">Exam Table</th>
                </tr>
                <tr align="center">
                    <th>Exam Code</th>
                    <th>Exam Name</th>
                    <th>Exam Date</th>
                    <th>Exam Time Start</th>
                    <th>Exam Time End</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Connect to database
                    $hostName = "localhost";
                    $userName = "root";
                    $password = "";
                    $databaseName = "giftedstudentdb";
                    
                    // Create Connection
                    $conn = new mysqli($hostName, $userName, $password, $databaseName);

                    // Check Connection
                    if ($conn ->connect_error){
                        die("Connection error: " . $conn ->connect_error);
                    }
                    else{
                        echo "Connection Success!";
                    }

                    // Check if form submitted
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        // Check if exam code or exam name submitted
                        if(isset($_POST['exam_code'])) {
                            $search_exam_code = $_POST['exam_code'] ?? '';
                            $query = "SELECT * FROM exam WHERE exam_code LIKE '%$search_exam_code%'";
                        } elseif(isset($_POST['exam_name'])) {
                            $search_exam_name = $_POST['exam_name'] ?? '';
                            $query = "SELECT * FROM exam WHERE exam_name LIKE '%$search_exam_name%'";
                        }
                    } else {
                        // Default query to fetch all exams
                        $query = "SELECT * FROM exam";
                    }
                    
                    // Execute the query
                    $result = $conn->query($query);
                    
                    if($result->num_rows > 0){
                        while($row = $result->fetch_assoc()){
                            echo "<tr>";
                            echo "<td>" . $row["exam_code"] . "</td>";
                            echo "<td>" . $row["exam_name"] . "</td>";
                            echo "<td>" . $row["exam_date"] . "</td>";
                            echo "<td>" . $row["exam_time_start"] . "</td>";
                            echo "<td>" . $row["exam_time_end"] . "</td>";
                            echo "<td><a href='TestPage.php?exam_code=" . $row["exam_code"] . "' class='Test-button' style='width: 100%; padding: 10px; background-color: blue; color: white; border: none; border-radius: 5px; cursor: pointer; display: block; text-align: center; text-decoration: none;'>Take this test</a></td>";
                            echo "</tr>";
                        }
                    }
                    else {
                        echo "<tr><td colspan='6'>No results found</td></tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
