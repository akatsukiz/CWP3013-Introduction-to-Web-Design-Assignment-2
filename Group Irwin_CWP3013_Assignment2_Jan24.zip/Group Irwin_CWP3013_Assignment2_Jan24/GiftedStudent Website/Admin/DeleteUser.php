<?php
	if(isset($_GET["id"])){
		$id=$_GET['id'];

		$hostName = "localhost";
		$userName = "root";
		$password = "";
		$databaseName = "giftedstudentdb";

		//Create Connection
		$conn = new mysqli($hostName, $userName, $password, $databaseName);

		$sql_delete_answers = "DELETE FROM student_answer WHERE stu_id = $id";
    	$conn->query($sql_delete_answers);

		$sql = "DELETE FROM user WHERE id=$id";
		$conn->query($sql);
	}

	header("Location: /Admin/UserDisplay.php");
	exit;

?>