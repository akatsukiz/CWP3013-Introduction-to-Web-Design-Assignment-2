<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admin | Student Adjustment</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
	<div class="container my-5">
		<h2>Student List</h2>
		<br>
		<a class="btn btn-primary" href="/Admin/CreateUser.php" role="button">New Student</a>
		<table class="table">
			<thread>
				<tr>
					<th>Id</th>
					<th>Name</th>
					<th>School Name</th>
					<th>Email</th>
					<th>Phone Number</th>
					<th>Address</th>
					<th>Type</th>
				</tr>
			</thread>
			<tbody>
				<?php
                // Connect to database
                $hostName = "localhost";
                $userName = "root";
                $password = "";
                $databaseName = "giftedstudentdb";
                // Create Connection
                $conn = new mysqli($hostName, $userName, $password, $databaseName);
                // Check Connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                else
                    echo "Connection Success!";
                // Fetch data from database

                $sql = "SELECT id, username, school, email, phone_no, address, type FROM user";
                $result = $conn->query($sql);
			   	if($result->num_rows>0) 
			   	{
					while($row=$result->fetch_assoc())
					{
						echo "
                            <tr>
                            	<td>$row[id]</td>
                                <td>$row[username]</td>
                                <td>$row[school]</td>
                                <td>$row[email]</td>
                                <td>$row[phone_no]</td>
                                <td>$row[address]</td>
                                <td>$row[type]</td>
                                <td>
                                    <a class='btn btn-primary btn-s' href='/Admin/EditUser.php?id=$row[id]'>Edit</a>
                                    <a class='btn btn-primary btn-s' href='/Admin/DeleteUser.php?id=$row[id]'>Delete</a>
                                </td>
                            </tr>
                            ";
                        }
                    }
                    else
                    {
						echo "no result";
					}
					$conn->close();
				?>
            </table>
		</table>
	</div>
</body>
</html>