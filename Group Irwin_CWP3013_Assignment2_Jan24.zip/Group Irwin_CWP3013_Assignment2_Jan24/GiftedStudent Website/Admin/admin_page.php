<?php
    // Connect to database
    $hostName = "localhost";
    $userName = "root";
    $password = "";
    $databaseName = "giftedstudentdb";
    // Create Connection
    $conn = new mysqli($hostName, $userName, $password, $databaseName);
    // Check Connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else
        echo "Connection Success!";
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Admin Page</title>
    <link rel="stylesheet" href="./CSS/admin_style.css">
</head>

<body>
    <div class ="container">
        <div class="user_button">
            <form method="POST" action= "../Admin/UserDisplay.php">
                <button type="navigate_user" name="user_button">Select User</button>
            </form>
        </div>

        <div class="schedule_button">
            <form method="POST" action="../Admin/check_result.php">
                <button type="navigate_schedule" name="schedule_button">Check Exam Result</button>
            </form>
        </div>

        <div class="generate_button">
            <form method="POST" action="../Admin/approval_list.php">
                <button type="navigate_generate" name="generate_button">Generate Code</button>
            </form>
        </div>

        <div class="check_button">
            <form method="POST" action="../Admin/AdminExamListing.php">
                <button type="navigate_check" name="check_button">Select Exam Schedule</button>
            </form>
        </div>
    </div>
</body>
</html>



