<?php
session_start();

if (isset($_SESSION["user_email"])) {
    header("Location: ../index.php", true, 303);
    die;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Log In</title>
    <link rel="stylesheet" href="./CSS/style.css">
</head>

<body>
    <main class="login_page">
        <div class="background"></div>
        <form action="./Helpers/login.php" method="POST">
            <a href="/">
                <img src="./images/logo.jpg" alt="Logo Gifted Students" loading="lazy">
            </a>
            <?php
            if (isset($_GET["error"])) :
                if ($_GET["error"] == 1) :
            ?>
                    <p class="error">Invalid credentials</p>
            <?php
                endif;
            endif;
            ?>
            <?php
            if (isset($_GET["sucess"])) :
                if ($_GET["sucess"] == 1) :
            ?>
                    <p class="sucess">Password has been modified successfully</p>
            <?php
                endif;
            endif;
            ?>
            <div class="input">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" required minlength="2" maxlength="96">
            </div>
            <div class="input">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div class="links">
                <a href="./forgot_password.php">Forgot password?</a>
                <p>Don't have an account ? <a href="/signup.php">Sign Up</a></p>
            </div>
            <button>Log In</button>
        </form>
    </main>
</body>

</html>