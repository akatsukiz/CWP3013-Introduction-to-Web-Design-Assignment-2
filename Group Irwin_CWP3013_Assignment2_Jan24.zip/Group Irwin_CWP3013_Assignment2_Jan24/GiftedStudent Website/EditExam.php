<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Students - Exam Edit</title>
    <style>
        body {
            position: relative;
            text-align: center;
            font-family: Arial, sans-serif;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 60px;
        }

        .form-input {
            width: 300px;
            padding: 10px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .readonly-input {
            background-color: #f0f0f0;
            color: #333;
            font-weight: bold;
        }

        .form-button {
            width: 200px;
            padding: 10px;
            background-color: blue;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php
    // Check if exam_code is provided in the URL
    if (isset($_GET['exam_code'])) {
        // Get the exam code from the URL
        $exam_code = $_GET['exam_code'];

        // Connect to the database
        $hostName = "localhost";
        $userName = "root";
        $password = "";
        $databaseName = "giftedstudentdb";
        $conn = new mysqli($hostName, $userName, $password, $databaseName);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch the existing exam details from the database
        $query = "SELECT * FROM exam WHERE exam_code = '$exam_code'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $exam_code = $row["exam_code"];
            $exam_name = $row["exam_name"];
            $exam_date = $row["exam_date"];
            $exam_time_start = $row["exam_time_start"];
            $exam_time_end = $row["exam_time_end"];
        }

        // Update the exam record in the database when the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm'])) {
            $exam_code = $_POST['exam_code'];
            $exam_name = $_POST['exam_name'];
            $exam_date = $_POST['exam_date'];
            $exam_time_start = $_POST['exam_time_start'];
            $exam_time_end = $_POST['exam_time_end'];

            // SQL query to update the exam record
            $update_query = "UPDATE exam SET exam_name='$exam_name', exam_date='$exam_date', exam_time_start='$exam_time_start', exam_time_end='$exam_time_end' WHERE exam_code='$exam_code'";

            if ($conn->query($update_query) === TRUE) {
                echo "<p>Exam record updated successfully</p>";
            } else {
                echo "Error updating exam record: " . $conn->error;
            }
        }
    }
    ?>

    <div class="form-container">
        <h1>Exam Edit</h1>
        <form action="" method="POST">
            Exam code : <input type="text" name="exam_code" value="<?php echo $exam_code; ?>" class="form-input readonly-input" readonly><br>
            Exam Name : <input type="text" name="exam_name" value="<?php echo $exam_name; ?>" class="form-input" placeholder="Exam Name" required><br>
            Exam Date : <input type="date" name="exam_date" value="<?php echo $exam_date; ?>" class="form-input" required><br>
            Exam Time : <input type="time" name="exam_time_start" value="<?php echo $exam_time_start; ?>" class="form-input" required> to
            <input type="time" name="exam_time_end" value="<?php echo $exam_time_end; ?>" class="form-input" required><br>
            <button type="submit" class="form-button" name="confirm">Confirmation</button>
        </form>
    </div>
</body>
</html>
